import random

class Fighter:
    def __init__(self, code):
        finalFile = open('finalMessages.txt', 'r')
        textFile = open('arena.txt', 'r')
        searchLines = textFile.readlines()
        textFile.close()


        self.code = code
        for i, line in enumerate(searchLines):
            if code in line:
                self.maxhp = float(searchLines[i+1])
                self.hp = self.maxhp
                self.AIMaxhp = float(searchLines[i+2])
                self.AIhp = self.AIMaxhp
                self.attack1v1 = searchLines[i+3]
                self.attack1v2 = searchLines[i+4]
                self.attack1v3 = searchLines[i+5]
                self.attack2v1 = searchLines[i+6]
                self.attack2v2 = searchLines[i+7]
                self.attack2v3 = searchLines[i+8]
                self.attack3v1 = searchLines[i+9]
                self.attack3v2 = searchLines[i+10]
                self.attack3v3 = searchLines[i+11]
                self.attack1v1Des = searchLines[i+12][:-1]
                self.attack1v2Des = searchLines[i+13][:-1]
                self.attack1v3Des = searchLines[i+14][:-1]
                self.attack2v1Des = searchLines[i+15][:-1]
                self.attack2v2Des = searchLines[i+16][:-1]
                self.attack2v3Des = searchLines[i+17][:-1]
                self.attack3v1Des = searchLines[i+18][:-1]
                self.attack3v2Des = searchLines[i+19][:-1]
                self.attack3v3Des = searchLines[i+20][:-1]
                self.attack1Help = searchLines[i+21][:-1]
                self.attack2Help = searchLines[i+22][:-1]
                self.attack3Help = searchLines[i+23][:-1]

        tempWin = ''
        tempLose = ''
        tempRespawn = ''

        for line in finalFile:
            if line.strip() == code:
                break
        for line in finalFile:
            if line.strip() == '$$':
                break
            else:
                tempWin += line + '\n'
        for line in finalFile:
            if line.strip() == '$$':
                break
            else:
                tempLose += line + '\n'
        for line in finalFile:
            if line.strip() == "$$":
                break
            else:
                tempRespawn += line + '\n'
                
        self.win = tempWin
        self.lose = tempLose
        self.respawn = tempRespawn
        finalFile.close()

    def getHp(self):
        return (self.hp, self.AIhp)

    def getAttack(self, yourAtk, AIAtk):
        pair = (yourAtk, AIAtk)
        if pair == (1,1):
            return self.attack1v1
        elif pair == (1,2):
            return self.attack1v2
        elif pair == (1,3):
            return self.attack1v3
        elif pair == (2,1):
            return self.attack2v1
        elif pair == (2,2):
            return self.attack2v2
        elif pair == (2,3):
            return self.attack2v3
        elif pair == (3,1):
            return self.attack3v1
        elif pair == (3,2):
            return self.attack3v2
        elif pair == (3,3):
            return self.attack3v3
        else:
            return 'something broke'

    def getAttackDes(self, yourAtk, AIAtk):
        pair = (yourAtk, AIAtk)
        if pair == (1,1):
            return self.attack1v1Des
        elif pair == (1,2):
            return self.attack1v2Des
        elif pair == (1,3):
            return self.attack1v3Des
        elif pair == (2,1):
            return self.attack2v1Des
        elif pair == (2,2):
            return self.attack2v2Des
        elif pair == (2,3):
            return self.attack2v3Des
        elif pair == (3,1):
            return self.attack3v1Des
        elif pair == (3,2):
            return self.attack3v2Des
        elif pair == (3,3):
            return self.attack3v3Des
        else:
            return 'something broke'

    def getAttackHelp(self, num):
        if num == 1:
            return self.attack1Help
        elif num == 2:
            return self.attack2Help
        elif num == 3:
            return self.attack3Help
        else:
            return 'something broke'

    def loseHp(self, loss):
        self.hp = self.hp - float(loss[0])
        self.AIhp = self.AIhp - float(loss[1])

    def resetHp(self):
        self.hp = self.maxhp
        self.AIhp = self.AIMaxhp

def fight(fighter):
    fighter.resetHp()
    print('{:<}'.format(fighter.respawn))
    while fighter.getHp()[0] > 0 and fighter.getHp()[1] > 0:
        AIAtk = random.randrange(1, 4)
        if fighter.code == '##6':
            if AIAtk == 1:
                atk = input("Your Hp: " + str(fighter.getHp()[0]*10) + "\nThe Warrior looks like he's gearing up for a big swing.\nWhat will you do? "
                    "Choose 1 2 or 3. Type 'help' to see what"
                    " your moves do." + "\n")
            elif AIAtk == 2:
                atk = input("Your Hp: " + str(fighter.getHp()[0]*10) + "\nYou guess that the Warrior's about to deliver a flurry of attacks.\nWhat will you do? "
                    "Choose 1 2 or 3. Type 'help' to see what"
                    " your moves do." + "\n")
            elif AIAtk == 3:
                atk = input("Your Hp: " + str(fighter.getHp()[0]*10) + "\nThe Warrior looks like he's charging up for a magical attack.\nWhat will you do? "
                    "Choose 1 2 or 3. Type 'help' to see what"
                    " your moves do." + "\n")
        elif fighter.code == '##G':
            atk = (input("Your Hp: " + str(fighter.getHp()[0]*10) + " You face off with Jaimie. What will you do? "
                        "Choose 1 2 or 3. Type 'help' to see what"
                        " your moves do." + "\n"))
        else:
            atk = (input("\nYour Hp: " + str(fighter.getHp()[0]*10) + " You face off with the Warrior. What will you do? "
                        "Choose 1 2 or 3. Type 'help' to see what"
                        " your moves do." + "\n"))
        if atk == '1' or atk == '2' or atk == '3':
            atk = int(atk)
            print("\n" * 100)
            print('\n' + '{:<}'.format(fighter.getAttackDes(atk, AIAtk)))
            fighter.loseHp(fighter.getAttack(atk, AIAtk))
        elif atk == 'help':
            print("\n" * 100)
            print('\n' + '{:<}'.format('Attack 1: ' + fighter.getAttackHelp(1) + '\n\n' +
                  'Attack 2: ' + fighter.getAttackHelp(2) + '\n\n' +
                  'Attack 3: ' + fighter.getAttackHelp(3) + '\n\n'))
        else:
            print('\n' + '{:<}'.format('Pick a valid option' + '\n'))

    if fighter.getHp()[0] > 0:
        print('{:<}'.format('\n' + fighter.win + '\n'))

        if fighter.code != "##6":
            print('Subtly, something in the universe shifts. Events wind back on themselves,'
                  'wiping away what had been...\n')
            input("Press enter to continue")
            print("\n" * 500)
        return False
    else:
        print('{:<}'.format('\n' + fighter.lose + '\n'))
        return True

################################################################################
def nextCode(code):
    num = int(code[2:])
    num = num + 1
    return "##" + str(num)

def printExpos(code):
    if code == '##3':
        file = open('textDump.txt', 'r')
        textDump = file.readlines()
        nothing = ''
        nothing2 = ''
        gnome1 = ''
        gnome2 = ''
        gnome3 = ''
        gnome4 = ''
        gnome5 = ''
        gnome6 = ''
        gnomeList = [nothing, nothing2, gnome1, gnome2, gnome3, gnome4, gnome5, gnome6]
        i = 0
        for line in textDump:
            if line.strip() == '$$':
                i += 1
            else:
                gnomeList[i] += line + '\n'
        file.close()
        print(gnomeList[2])
        oneOrTwo = -1
        while oneOrTwo != '1' and oneOrTwo != '2':
            oneOrTwo = input('Choose 1 or 2. ')
        if oneOrTwo == '1':
            print(gnomeList[3])
            fighter = Fighter('##G')
            lose = fight(fighter)
            if not lose:
                print(gnomeList[4])
            else:
                print(gnomeList[5])
        else:
            print(gnomeList[6])
        print(gnomeList[7])
    else:
        textFile = open('expos.txt', 'r')
        for line in textFile:
            if line.strip() == code:
                break
        textList = []
        for line in textFile:
            if line.strip() == '@@':
                break
            else:
                textList.append(line)
        printing = True
        for line in textList:
            if line == '$$$$\n':
                oneOrTwo = -1
                while oneOrTwo != '1' and oneOrTwo != '2':
                    oneOrTwo = input('Choose 1 or 2. ')
                if oneOrTwo == '1':
                    printing = True
                    continue
                else:
                    printing = False
                print('\n')
            if line == '$$$\n':
                if printing:
                    printing = False
                else:
                    printing = True
                    continue
            if line.strip() == "$$":
                printing = True
                continue
            if printing:
                print('{:<}'.format(line))
                #input("\nPress enter to continue\n")

def gameTime():
    file = open('arenaSave.txt', "r")
    code = file.read(3)
    file.close()
    if code == '':
        file = open('textDump.txt', 'r')
        intro = ""
        for line in file:
            if line.strip() == "$$":
                break
            else:
                print(line)
                #input("\n...\n")
        for line in file:
            if line.strip() == "$$":
                break
            else:
                intro += line
        print(intro)
        file.close()
        code = '##1'
    if code == '##7':
        yn = 0
        while yn != 'y' and yn != 'n':
            yn = input("This story has ended. Delete save file? (y/n)")
        if yn == 'y':
            file = open('arenaSave.txt', 'w+')
            file.close
        elif yn == 'n':
            print('Thanks for playing.')
            file = open('arenaSave.txt', 'w+')
            print('##7', file=file)
            file.close()
        return
    printExpos(code)
    currentFighter = Fighter(code)
    lose = False
    if code != "##6":
        while not lose:
            lose = fight(currentFighter)
    else:
        lose = fight(currentFighter)
    code = nextCode(code)
    file = open('arenaSave.txt', 'w+')
    print(code, file=file)
    file.close()
    if code == '##7':
        if lose:
            print('Grand Champion Shin Heideki was killed in the arena fight against the mysterious Warrior. The Warrior ascended to Grand Champion, and held the title for an astonishingly long time. Frustrated by the seeming impossiblility of the Warriors defeat, interest in the Arena slackened. Crowds got smaller and smaller, until eventually the Arena became a shadow of what it once was, a hollowed out reminder of better times.')
        else:
            print("Grand Champion Shin Heideki retired shortly after his fight against the Warrior. He went on to become a successful teacher at the Mage's college in Rask. He is generally well regarded, although rumor has it that he is involved in providing aid to the Gnomish resistance movement. Arena life continues as normal, with several promising young prospects competing for Heideki's spot. The current favourite is a young peasent who fights like a knight. He's rising quickly, and seems to be motivated by a goal deeper than money or fame. All in all, things are back to normal.")
        yn = 0
        while yn != 'y' and yn != 'n':
            yn = input("This story has ended. Delete save file? (y/n)")
        if yn == 'y':
            file = open('arenaSave.txt', 'w+')
            file.close
        elif yn == 'n':
            print('Thanks for playing.')
            file = open('arenaSave.txt', 'w+')
            print('##7', file=file)
            file.close()
        return
    stayOrGo = input("Game Saved. Select 1 to continue, 2 to quit.")
    while stayOrGo != '1' and stayOrGo != '2':
        stayOrGo = input("Select 1 to continue, 2 to quit")
    if stayOrGo == '2':
        return
    else:
        print("\n" * 500)
        gameTime()

gameTime()

#(c) Thomas Hvizdos. Some rights reserved.