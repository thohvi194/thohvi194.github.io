______ ___________ _____ _____ _____  ___  ___  ___
|  ___|_   _| ___ \  ___|_   _|  ___|/ _ \ |  \/  |
| |_    | | | |_/ / |__   | | | |__ / /_\ \| .  . |
|  _|   | | |    /|  __|  | | |  __||  _  || |\/| |
| |    _| |_| |\ \| |___  | | | |___| | | || |  | |
\_|    \___/\_| \_\____/  \_/ \____/\_| |_/\_|  |_/
                                                   
PROLOGUE:
It's fall 2000, and the fifth year of WW3 is drawing to a close. Three years ago you were a leitennent, leading an American squad on a NATO offensive against Warsaw Pact forces in central Chezchoslovakia, when you saw flashes on the distance--tactical nuclear strikes. Both sides claimed the other was the first to use nukes, but both continued to use them until things escalated past the point of no return.
Now, the war has changed. Large scale battles have become uncommon, and your unit, the 102nd, has been camped outside the Polish city of Kielce for almost six monthes, digging in and growing crops to replace nonexistant supply lines. Orders from the United States have become increasingly rare, and, it's been several months since anything has been heard. The generals in the area have largely taken over the operations of their units, and an ad-hoc barter network has emerged between your unit and several other NATO-affiliated nations in the area.
For their part, the Ukranian army, the primary Communist forces in the area, have been quiet as well over the past few months, presumably in similar situations. You've little knowledge of the world at large, but, if Kielce is any indication, most civilian governments are in tatters, with major metropolitan areas becoming city-states, and smaller communities tucking in and making do the best they can.
The last few months have been peaceful. But Leutenent Colonal Hood has sent you a cryptic summons, and you have the sense things are about to change...

INTRODUCTION:
FireTeam is a turn-based, squad-level tactical shooter, where cover and resource management play a large role in survival. While playing FireTeam, you will alternate between combat and narrative segments. In combat segments, you'll direct the soldiers under your command to move, fire, take cover, use abilities, etc., in an attempt to kill your enemies while suffering the smallest possible amount of negative consequences. In narrative segments, you'll read about your team's actions, and make command decisions based on the situation.  These command decisions will have significant impacts on your team's mission and the story of the game overall.

KEY CONCEPTS:

Movement: FireTeam takes placed on a grid based map. Each soldier by deafault can move 4 spaces in any direction in a turn. Tell your squad member to move by clicking on them, pressing the "M" key, and clicking the spot you would like them to move to.

Firing: Each member of your team is equipped with a weapon suited to their role. By default, weapons have a range of 7 squares. Characters must have line of sight to their taget to fire at it.

Aim: When you have a character selected, you'll see the words "Aim: XX" under their character portrait. This number represents their chances out of 100 to hit a target out of cover. Some characters have more combat experience and skill than others, and this is reflected in their aim score. Aim can be changed in several ways: by suffering a wound, having a lingering wound, special abilities, or if the target is in cover.

Wounds: In combat, a character can be healthy, wounded, or seriously wounded. The first time a character takes damage, they become wounded. Wounded characters take a -30% penalty to aim. If a character is damaged a second time, they become seriously wounded, and incapacitated. The character is removed from the battlefield to represent their inability to continue fighting. If a character suffers a serious wound, and is not treated, their wound lingers, and they will be at a -10% aim penalty for the next combat encounter.

Hand-To-Hand Combat: To conserve ammunition, you may wish to direct members of your team to engage in hand-to-hand combat with the enemy instead of firing at them. You may do this by moving a character adjacent to an enemy and pressing the "H" key. Odds for hand to hand combat are as follows:
81-100: Enemy is killed.
51-80: Enemy is injured.
11-50: No effect.
1-10: Attacker is injured.


Terrain: There are several types of terrain in FireTeam. Terrain affects your characters chances of hitting their target and being hit. During a battle, you can press the "C" key to see the terrain attributes of your surroundings.

Heavy Cover: This represents some feature that provides substantial cover to the character, but does not block line of sight. Characters firing at another character in heavy cover suffer a -30% aim penalty. Heavy cover cannot be moved through. Heavy cover is represented by a brown overlay.

Light Cover: This cover doesn't do much, but it's better than nothing. Characters firign at another character in light cover suffer a -10% aim penalty. Light cover can be moved through. It is represented by a yellow overlay.

Blocking: This type of terrain represents solid obstacles such as walls. Blocking terrain cannot be moved or shot through. It is represented by a grey/black overlay.

Impassable: This represents terrain that can be shot over, but not moved through. Examples: water, pits. It is represented by a blue overlay.

Ammunition: Your squad has a limited amount of ammo. For simplicity's sake, ammunition type is not considered; every character draws from the same pool. You may acquire ammo from narrative events. Each shot consumes 1 unit of ammo.

Medicine: In the world of fireteam, medical supplies have become scarse. Healing a character uses 1 unit of medicine. Treating a seriously wounded character after a combat is over takes 3 units of medicine.

Abilities: Some characters can use special abilites, representing talents or features of the character's weapon. If a character has an ability that can be used actively, you can activate it by pressing the "A" key on your keyboard. Note: a character cannot attack and use an ability in the same turn.

Controls: Click a character to select them. Right click to cancel selection. Arrow keys move the map, and "+" and "-" keys zoom in and out.

CHARACTERS:
Sergeant Moses "Bull" Cassidy: An American farm boy from Iowa, Bull joined the US Army as a volunteer, and served in the Second Mexican-American War. He's extremely capable with his M249 Light Machine Gun, and has picked up a number of useful tricks from experience.
Weapon: M249 LMG
Aim: 80
Abilities:
Burst: Bull fires off a three round burst from his squad support weapon. Each shot uses one ammo. Each shot has an independent chance to hit or miss.
Hard-To-Kill: Bull is especially tough, and can take an extra hit of damage before becoming wounded.
Ruthless: If a hand-to-hand combat would wound an enemy, they are killed instead.

Corporal Beate Adler: Beate grew up in West Berlin. In the early 1990s, sensing conflict, the US and USSR planted opposing paramilitary groups on opposite sides of the Berlin Wall, hoping that theirs would emerge as a clear victor and force the other side to withdraw officially. Instead, Berlin became a city ravaged by gang warfare. With the recent general collapse of civilian government, the opposing gangs have essentially taken over the city. Beate served in the Pro-Democracy "Vereinigen Deutschland!" movement from a young age, and became extremely adept at urban combat and guerilla tactics. How she ended up in a German regular army unit is a bit of a mystery...
Weapon: H&K FABARM FP6
Aim: See below.
Abilities:
Shotgun Special Rules: Shotguns are most effective in close quarters. Beate's default aim is 30, but that increases to 80 if she is within 4 squares of her target. If she is within 2 squares, a shot that hits an enemy instantly kills it.
Fast: Beate can move 5 squares per turn.
Hard-to-Kill: Beate is especially tough, and can take an extra hit of damage before becoming wounded.
Hand-To-Hand Specialist: Beate has a great deal of experience in fights, and rolls 30 points higher on the hand-to-hand combat table.

Private Lachlan Magoro: A child of South African immigrants, Magoro was drafted shortly after entering college. An excellent marksmen, he was trained as a sniper by the Royal Army and immediately shipped to Poland. He has little interest in the war.
Weapon: L118A1
Aim: 90
Abilities:
Sniper Rifle Special Rules: Magoro cannot move and fire in the same turn. However, his rifle's accuracy and power means that any hit on an enemy results in a kill.

Specialist Karine Merle: A civilian doctor, Karine was drafted by the French Army and now serves as a medic. She has had limited combat experience, but her medical skills are second-to-none.
Weapon: FAMAS F1
Aim: 60
Abilites:
Patch Up: Karine uses one unit of medicine to change a teammate's status from "wounded" to "healthy."

Leiutenent Sarah Howard: Your character for the duration of FireTeam. A career officer, you graduated from West Point, and were one of the first female officers serving in combat when that restriction was lifted in 1996. Your career has been commendable, if uneventful.
Weapon: M16A4
Aim: 70
Abilities:
Inspire: You call on one of the members of your squad to perform, giving any shots they take that turn a 100% chance to hit, regardless of cover.


CREDITS:
Thomas Hvizdos
Setting is derived almost entirely from the RPG Tyrion 2000, by the Game Developers Workshop
This work is licensed under the Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International License. To view a copy of this license, visit http://creativecommons.org/licenses/by-nc-sa/4.0/ or send a letter to Creative Commons, PO Box 1866, Mountain View, CA 94042, USA.




















